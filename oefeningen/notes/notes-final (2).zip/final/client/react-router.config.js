export default {
  ssr: false,
};
