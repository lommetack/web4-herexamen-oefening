export const testdata = {
  folders: [
    {
      id: "f1",
      name: "Getting Started",
    },
    {
      id: "f2",
      name: "Personal",
    },
  ],
  notes: [
    {
      id: "n1",
      folderId: "f1",
      title: "Welcome to NotePad",
      content:
        '# Welcome to NotePad!\n\nThis is your new favorite note-taking application. Here\'s what you can do:\n\n## Features\n- Create and organize notes in folders\n- Format your notes with Markdown\n- Easily navigate between notes\n- Create new folders to organize your work\n- Dark mode support\n\n## Getting Started\n1. Click on "New Note" to create a new note\n2. Use the "New Folder" button to create a new folder\n3. Click on any note to view and edit its content\n4. Save automatically as you type\n\nFeel free to explore and organize your thoughts!',
    },
    {
      id: "n2",
      folderId: "f2",
      title: "Shopping List",
      content:
        "# Shopping List\n\n- Milk\n- Eggs\n- Bread\n- Coffee\n- Apples\n- Pasta\n- Tomato sauce",
    },
    {
      id: "n3",
      folderId: "f2",
      title: "Project Ideas",
      content:
        "# Future Project Ideas\n\n1. Learn a new programming language\n2. Build a mobile app\n3. Create a personal website\n4. Contribute to open source",
    },
  ],
};

export const newFolder = {
  id: "f3",
  name: "New Folder",
};

export const newNote = {
  id: "n4",
  title: "New Note",
  content: "# New Note\n\nThis is a new note.",
};
